const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// In-memory simulated data
const campusData = {
    library: { 
        status: "open", 
        capacity: 200, 
        occupied: 75,
        temperature: 24.5,
        humidity: 40.2
    },
    dining_hall: { 
        status: "open", 
        menu: ["Pizza", "Salad", "Pasta", "Burgers", "Soup"]
    },
    gym: {
        status: "open",
        capacity: 50,
        occupied: 23,
        equipment_available: 45
    },
    parking: {
        total_spots: 500,
        available: 127,
        status: "available"
    }
};

// Simulated AI response function
function simpleAIResponse(userQuery) {
    const query = userQuery.toLowerCase();
    
    if (query.includes('library')) {
        const data = campusData.library;
        return `The library is ${data.status} with ${data.occupied}/${data.capacity} people. Current temperature: ${data.temperature}°C, humidity: ${data.humidity}%.`;
    } else if (query.includes('menu') || query.includes('dining') || query.includes('food')) {
        const menu = campusData.dining_hall.menu;
        return `Today's dining menu includes: ${menu.join(', ')}. The dining hall is currently ${campusData.dining_hall.status}.`;
    } else if (query.includes('gym') || query.includes('workout')) {
        const data = campusData.gym;
        return `The gym is ${data.status} with ${data.occupied}/${data.capacity} people. ${data.equipment_available} pieces of equipment are available.`;
    } else if (query.includes('parking')) {
        const data = campusData.parking;
        return `Parking status: ${data.available}/${data.total_spots} spots available. Status: ${data.status}.`;
    } else if (query.includes('help') || query.includes('what can you do')) {
        return "I can help you with information about the library, dining hall menu, gym availability, and parking spots. Try asking about any of these facilities!";
    } else {
        return "Sorry, I don't have information about that. I can help you with library, dining hall, gym, or parking information.";
    }
}

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/chat', (req, res) => {
    const { user_query } = req.body;
    if (!user_query) {
        return res.status(400).json({ error: 'user_query is required' });
    }
    
    const response = simpleAIResponse(user_query);
    res.json({ response });
});

app.get('/api/facility/:facility', (req, res) => {
    const facility = req.params.facility;
    const data = campusData[facility];
    
    if (!data) {
        return res.status(404).json({ error: 'Facility not found' });
    }
    
    res.json(data);
});

app.get('/api/facilities', (req, res) => {
    res.json(campusData);
});

// WebSocket connection for real-time updates
wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    
    ws.on('close', () => {
        console.log('Client disconnected from WebSocket');
    });
});

// Sensor data simulator
function simulateSensorData() {
    const facilities = ['library', 'gym'];
    
    facilities.forEach(facility => {
        if (campusData[facility]) {
            // Simulate realistic changes
            campusData[facility].occupied = Math.max(0, 
                campusData[facility].occupied + Math.floor(Math.random() * 21) - 10
            );
            campusData[facility].occupied = Math.min(
                campusData[facility].capacity, 
                campusData[facility].occupied
            );
            
            if (facility === 'library') {
                campusData[facility].temperature = 
                    Math.round((22 + Math.random() * 6) * 10) / 10;
                campusData[facility].humidity = 
                    Math.round((30 + Math.random() * 20) * 10) / 10;
            }
        }
    });
    
    // Update parking
    campusData.parking.available = Math.max(0, 
        campusData.parking.available + Math.floor(Math.random() * 21) - 10
    );
    campusData.parking.available = Math.min(
        campusData.parking.total_spots, 
        campusData.parking.available
    );
    
    // Broadcast updates to connected WebSocket clients
    const sensorData = {
        timestamp: new Date().toISOString(),
        facilities: campusData
    };
    
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(sensorData));
        }
    });
    
    console.log(`[Sensor Update] ${new Date().toISOString()}`, 
        `Library: ${campusData.library.occupied}/${campusData.library.capacity}`, 
        `Parking: ${campusData.parking.available}/${campusData.parking.total_spots}`
    );
}

// Start sensor simulation
setInterval(simulateSensorData, 5000);

const PORT = process.env.PORT || 8000;
server.listen(PORT, () => {
    console.log(`Smart Campus Assistant API running on http://localhost:${PORT}`);
    console.log(`WebSocket server running for real-time updates`);
});